(function () {
    'use strict';

    angular.module('selfService', [      
      'ngAnimate', 
      'ngCookies', 
      'ngSanitize',
      'ngResource', 
      'ui.router', 
      'ngMaterial', 
      'nvd3',
      'md.data.table',
      'pascalprecht.translate'
    ])

})();